#define SOLE_BUILD_TESTS
#include "sole.hpp"
